<?php
// Script de vérification de l'installation

echo "<h1>Vérification Installation Nowlover</h1>";
echo "<style>body{font-family:sans-serif;padding:20px;} .ok{color:green;} .error{color:red;} .warn{color:orange;}</style>";

echo "<h2>1. Structure des fichiers</h2>";

$requiredFiles = [
    'index.html' => 'Page principale',
    'assets/index-w-YkMX3w.js' => 'JavaScript principal',
    'assets/index-BYe7cwR8.css' => 'CSS principal',
    'backend/config/database.php' => 'Config database',
    'backend/middleware/cors.php' => 'Middleware CORS',
    'backend/middleware/auth.php' => 'Middleware Auth',
    'backend/models/User.php' => 'Modèle User',
    'backend/api/auth.php' => 'API Auth',
    'backend/api/countries.php' => 'API Countries',
    '.htaccess' => 'Configuration Apache',
];

$missingFiles = [];
foreach ($requiredFiles as $file => $desc) {
    if (file_exists($file)) {
        echo "<div class='ok'>✅ $desc: $file</div>";
    } else {
        echo "<div class='error'>❌ MANQUANT: $desc ($file)</div>";
        $missingFiles[] = $file;
    }
}

echo "<h2>2. Test connexion base de données</h2>";

try {
    require_once 'backend/config/database.php';
    $db = Database::getInstance();
    echo "<div class='ok'>✅ Connexion MySQL réussie!</div>";
    
    echo "<h2>3. Vérification des tables</h2>";
    
    $tables = ['users', 'members', 'countries', 'localities', 'products', 'partner_shops', 'membership_levels', 'orders', 'admin_users', 'site_settings'];
    
    foreach ($tables as $table) {
        try {
            $stmt = $db->query("SELECT COUNT(*) as c FROM $table");
            $result = $stmt->fetch();
            $count = $result['c'];
            
            if ($count > 0) {
                echo "<div class='ok'>✅ Table $table: $count enregistrements</div>";
            } else {
                echo "<div class='warn'>⚠️ Table $table: vide</div>";
            }
        } catch (Exception $e) {
            echo "<div class='error'>❌ Table $table: " . $e->getMessage() . "</div>";
        }
    }
    
    echo "<h2>4. Vérification Admin</h2>";
    
    $stmt = $db->query("SELECT u.email, m.code, a.role FROM users u LEFT JOIN members m ON u.id = m.id LEFT JOIN admin_users a ON u.id = a.user_id WHERE u.email = 'rikaconcept@gmail.com'");
    $admin = $stmt->fetch();
    
    if ($admin) {
        echo "<div class='ok'>✅ Admin trouvé:</div>";
        echo "<ul>";
        echo "<li>Email: {$admin['email']}</li>";
        echo "<li>Code: " . ($admin['code'] ?? 'N/A') . "</li>";
        echo "<li>Role: " . ($admin['role'] ?? 'N/A') . "</li>";
        echo "</ul>";
    } else {
        echo "<div class='error'>❌ Admin NON TROUVÉ</div>";
    }
    
} catch (Exception $e) {
    echo "<div class='error'>❌ Erreur: " . $e->getMessage() . "</div>";
}

echo "<h2>5. Résumé</h2>";

if (count($missingFiles) > 0) {
    echo "<div class='error'><strong>❌ " . count($missingFiles) . " fichiers manquants!</strong></div>";
    echo "<p>Fichiers manquants:</p><ul>";
    foreach ($missingFiles as $file) {
        echo "<li>$file</li>";
    }
    echo "</ul>";
} else {
    echo "<div class='ok'><strong>✅ Tous les fichiers sont présents!</strong></div>";
}

echo "<hr><h3>Chemin serveur:</h3><code>" . __DIR__ . "</code>";
echo "<h3>PHP Version:</h3><code>" . phpversion() . "</code>";
