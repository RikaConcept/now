#!/usr/bin/env php
<?php
/**
 * ÉTAPE 2: Mettre à jour les données des pays
 * Exécutez via navigateur: https://arnowconcept.com/step2-update-countries.php
 */

require_once 'backend/config/database.php';

echo "<h1>\u00c9tape 2: Mise \u00e0 jour donn\u00e9es pays</h1><pre>\n";

try {
    $db = Database::getInstance();
    
    $countriesData = [
        'FR' => ['+33', '+33 6 XX XX XX XX', 'EUR', 'France'],
        'BE' => ['+32', '+32 4XX XX XX XX', 'EUR', 'Belgique'],
        'CH' => ['+41', '+41 XX XXX XX XX', 'CHF', 'Suisse'],
        'CA' => ['+1', '+1 XXX XXX XXXX', 'CAD', 'Canada'],
        'CI' => ['+225', '+225 XX XX XX XX XX', 'XOF', 'C\u00f4te d\'Ivoire'],
        'CM' => ['+237', '+237 6 XX XX XX XX', 'XAF', 'Cameroun'],
        'SN' => ['+221', '+221 XX XXX XX XX', 'XOF', 'S\u00e9n\u00e9gal'],
        'BJ' => ['+229', '+229 XX XX XX XX', 'XOF', 'B\u00e9nin'],
        'TG' => ['+228', '+228 XX XX XX XX', 'XOF', 'Togo'],
        'BF' => ['+226', '+226 XX XX XX XX', 'XOF', 'Burkina Faso'],
        'ML' => ['+223', '+223 XX XX XX XX', 'XOF', 'Mali'],
        'GA' => ['+241', '+241 X XX XX XX', 'XAF', 'Gabon'],
        'CD' => ['+243', '+243 XX XXX XXXX', 'CDF', 'RDC'],
        'MA' => ['+212', '+212 6XX XX XX XX', 'MAD', 'Maroc'],
        'NG' => ['+234', '+234 XXX XXX XXXX', 'NGN', 'Nigeria'],
        'GH' => ['+233', '+233 XX XXX XXXX', 'GHS', 'Ghana'],
        'DE' => ['+49', '+49 XXX XXXXXXX', 'EUR', 'Allemagne'],
        'LU' => ['+352', '+352 XXX XXX', 'EUR', 'Luxembourg'],
        'ES' => ['+34', '+34 XXX XX XX XX', 'EUR', 'Espagne'],
        'IT' => ['+39', '+39 XXX XXX XXXX', 'EUR', 'Italie'],
        'PT' => ['+351', '+351 XXX XXX XXX', 'EUR', 'Portugal'],
        'GB' => ['+44', '+44 XXXX XXXXXX', 'GBP', 'Royaume-Uni'],
        'ZA' => ['+27', '+27 XX XXX XXXX', 'ZAR', 'Afrique du Sud'],
        'EG' => ['+20', '+20 XXX XXX XXXX', 'EGP', '\u00c9gypte'],
    ];
    
    $updated = 0;
    foreach ($countriesData as $code => [$prefix, $format, $currency, $name]) {
        $result = $db->query(
            "UPDATE countries SET phone_prefix = ?, phone_format = ?, currency_code = ? WHERE code = ?",
            [$prefix, $format, $currency, $code]
        );
        echo "\u2713 $name ($code): $prefix / $currency\n";
        $updated++;
    }
    
    echo "\n\u2705 $updated pays mis \u00e0 jour!\n";
    echo "\nProchaine \u00e9tape: Ex\u00e9cutez step3-insert-localities.php\n";
    
} catch (Exception $e) {
    echo "\u274c Erreur: " . $e->getMessage() . "\n";
}

echo "</pre>";
