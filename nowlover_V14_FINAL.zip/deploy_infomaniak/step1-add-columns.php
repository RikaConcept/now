#!/usr/bin/env php
<?php
/**
 * ÉTAPE 1: Ajouter colonnes phone_prefix, phone_format, currency_code
 * Exécutez ce script via navigateur: https://arnowconcept.com/step1-add-columns.php
 */

require_once 'backend/config/database.php';

echo "<h1>\u00c9tape 1: Ajout colonnes countries</h1><pre>\n";

try {
    $db = Database::getInstance();
    
    echo "V\u00e9rification et ajout des colonnes...\n\n";
    
    // phone_prefix
    $stmt = $db->query("SHOW COLUMNS FROM countries LIKE 'phone_prefix'");
    if (!$stmt->fetch()) {
        $db->query("ALTER TABLE countries ADD COLUMN phone_prefix VARCHAR(10) AFTER flag_emoji");
        echo "\u2705 phone_prefix ajout\u00e9\n";
    } else {
        echo "\u2713 phone_prefix existe\n";
    }
    
    // phone_format
    $stmt = $db->query("SHOW COLUMNS FROM countries LIKE 'phone_format'");
    if (!$stmt->fetch()) {
        $db->query("ALTER TABLE countries ADD COLUMN phone_format VARCHAR(50) AFTER phone_prefix");
        echo "\u2705 phone_format ajout\u00e9\n";
    } else {
        echo "\u2713 phone_format existe\n";
    }
    
    // currency_code
    $stmt = $db->query("SHOW COLUMNS FROM countries LIKE 'currency_code'");
    if (!$stmt->fetch()) {
        $db->query("ALTER TABLE countries ADD COLUMN currency_code VARCHAR(10) AFTER phone_format");
        echo "\u2705 currency_code ajout\u00e9\n";
    } else {
        echo "\u2713 currency_code existe\n";
    }
    
    echo "\n\u2705 Colonnes pr\u00eates!\n";
    echo "\nProchaine \u00e9tape: Ex\u00e9cutez step2-update-countries.php\n";
    
} catch (Exception $e) {
    echo "\u274c Erreur: " . $e->getMessage() . "\n";
}

echo "</pre>";
