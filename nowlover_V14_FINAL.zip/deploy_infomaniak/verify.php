<?php
echo "<h1>Vérification Installation</h1><pre>\n";

$requiredFiles = [
    'index.html',
    'assets/index-w-YkMX3w.js',
    'backend/middleware/cors.php',
    'backend/api/countries.php',
];

$missing = [];
foreach ($requiredFiles as $file) {
    echo (file_exists($file) ? "✅" : "❌") . " $file\n";
    if (!file_exists($file)) $missing[] = $file;
}

if (count($missing) == 0) {
    require_once 'backend/config/database.php';
    $db = Database::getInstance();
    echo "\n✅ BDD connectée\n\n";
    
    $tables = ['countries', 'localities', 'site_settings', 'users', 'admin_users'];
    foreach ($tables as $t) {
        $stmt = $db->query("SELECT COUNT(*) as c FROM $t");
        echo "Table $t: " . $stmt->fetch()['c'] . "\n";
    }
    
    $stmt = $db->query("SELECT * FROM users WHERE email='rikaconcept@gmail.com'");
    echo "\nAdmin: " . ($stmt->fetch() ? "✅ Existe" : "❌ Manquant") . "\n";
} else {
    echo "\n❌ ". count($missing) . " fichiers manquants\n";
}
echo "</pre>";
