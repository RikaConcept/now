<?php
echo "<h1>Création Middleware</h1><pre>";
$dir = 'backend/middleware';
if (!is_dir($dir)) mkdir($dir, 0755, true);

file_put_contents("$dir/cors.php", "<?php\nfunction handleCORS() {\n    if (isset(\$_SERVER['HTTP_ORIGIN'])) {\n        header(\"Access-Control-Allow-Origin: {\$_SERVER['HTTP_ORIGIN']}\");\n        header('Access-Control-Allow-Credentials: true');\n    }\n    if (\$_SERVER['REQUEST_METHOD'] == 'OPTIONS') {\n        header(\"Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS\");\n        if (isset(\$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {\n            header(\"Access-Control-Allow-Headers: {\$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}\");\n        }\n        exit(0);\n    }\n}\nhandleCORS();");

file_put_contents("$dir/auth.php", "<?php\nrequire_once __DIR__ . '/../utils/JWT.php';\nrequire_once __DIR__ . '/../utils/Response.php';\nfunction authenticate() {\n    \$headers = getallheaders();\n    if (!isset(\$headers['Authorization'])) Response::unauthorized('No token');\n    if (!preg_match('/Bearer\\\\s+(\\\\S+)/', \$headers['Authorization'], \$m)) Response::unauthorized('Invalid format');\n    try { return JWT::decode(\$m[1]); } catch (Exception \$e) { Response::unauthorized('Invalid token'); }\n}\nfunction requireAdmin() {\n    \$user = authenticate();\n    if (!isset(\$user['is_admin']) || !\$user['is_admin']) Response::forbidden('Admin required');\n    return \$user;\n}");

echo "✅ Fichiers créés!\nSupprimez ce fichier maintenant.\n</pre>";
