<?php
// Test API Countries
header('Content-Type: text/html; charset=utf-8');

echo "<h1>Test API Countries</h1>";

echo "<h2>1. Test direct countries.php</h2>";
echo "<pre>";

try {
    ob_start();
    require 'backend/api/countries.php';
    $output = ob_get_clean();
    
    echo "Sortie brute:\n";
    echo htmlspecialchars($output);
    
} catch (Exception $e) {
    echo "Erreur: " . $e->getMessage();
}

echo "</pre>";

echo "<h2>2. Test via include</h2>";
echo "<pre>";

// Capturer l'output
$ch = curl_init('http://localhost/backend/api/countries.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Code: $httpCode\n";
echo "Réponse:\n";
echo htmlspecialchars($response);

echo "</pre>";

echo "<h2>3. Test connexion DB</h2>";
echo "<pre>";

try {
    require_once 'backend/config/database.php';
    $db = Database::getInstance();
    
    $stmt = $db->query("SELECT * FROM countries LIMIT 5");
    $countries = $stmt->fetchAll();
    
    echo "Pays trouvés: " . count($countries) . "\n\n";
    echo json_encode($countries, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (Exception $e) {
    echo "Erreur DB: " . $e->getMessage();
}

echo "</pre>";
