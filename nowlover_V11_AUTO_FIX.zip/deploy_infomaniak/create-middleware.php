<?php
/**
 * Script de création des fichiers manquants
 * Exécutez ce fichier via navigateur pour créer automatiquement
 * les fichiers backend/middleware qui manquent
 */

echo "<h1>Création des fichiers manquants</h1>";
echo "<pre>";

// Créer le dossier middleware s'il n'existe pas
$middlewareDir = __DIR__ . '/backend/middleware';
if (!is_dir($middlewareDir)) {
    mkdir($middlewareDir, 0755, true);
    echo "✓ Dossier créé: backend/middleware/\n";
} else {
    echo "✓ Dossier existe: backend/middleware/\n";
}

// Créer cors.php
$corsContent = <<<'PHP'
<?php

function handleCORS() {
    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');
    }
    
    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD'])) {
            header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
        }
        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS'])) {
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
        }
        exit(0);
    }
}

handleCORS();
PHP;

file_put_contents($middlewareDir . '/cors.php', $corsContent);
echo "✓ Fichier créé: backend/middleware/cors.php\n";

// Créer auth.php
$authContent = <<<'PHP'
<?php

require_once __DIR__ . '/../utils/JWT.php';
require_once __DIR__ . '/../utils/Response.php';

function authenticate() {
    $headers = getallheaders();
    
    if (!isset($headers['Authorization'])) {
        Response::unauthorized('No authorization token provided');
    }
    
    $authHeader = $headers['Authorization'];
    
    if (!preg_match('/Bearer\s+(\S+)/', $authHeader, $matches)) {
        Response::unauthorized('Invalid authorization header format');
    }
    
    $token = $matches[1];
    
    try {
        $payload = JWT::decode($token);
        return $payload;
    } catch (Exception $e) {
        Response::unauthorized('Invalid or expired token: ' . $e->getMessage());
    }
}

function requireAdmin() {
    $user = authenticate();
    
    if (!isset($user['is_admin']) || !$user['is_admin']) {
        Response::forbidden('Admin access required');
    }
    
    return $user;
}
PHP;

file_put_contents($middlewareDir . '/auth.php', $authContent);
echo "✓ Fichier créé: backend/middleware/auth.php\n";

echo "\n=== Vérification ===\n";

if (file_exists($middlewareDir . '/cors.php') && file_exists($middlewareDir . '/auth.php')) {
    echo "✅ Tous les fichiers middleware sont créés!\n\n";
    echo "Testez maintenant:\n";
    echo "- https://arnowconcept.com/api/countries\n";
    echo "- https://arnowconcept.com/api/localities\n\n";
    echo "Puis supprimez ce fichier create-middleware.php pour sécurité.\n";
} else {
    echo "❌ Erreur lors de la création des fichiers\n";
}

echo "</pre>";
